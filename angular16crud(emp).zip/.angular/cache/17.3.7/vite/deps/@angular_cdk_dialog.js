import {
  CdkDialogContainer,
  DEFAULT_DIALOG_CONFIG,
  DIALOG_DATA,
  DIALOG_SCROLL_STRATEGY,
  DIALOG_SCROLL_STRATEGY_PROVIDER,
  DIALOG_SCROLL_STRATEGY_PROVIDER_FACTORY,
  Dialog,
  DialogConfig,
  DialogModule,
  DialogRef,
  throwDialogContentAlreadyAttachedError
} from "./chunk-ALY3ATZK.js";
import "./chunk-4JVXZGY2.js";
import "./chunk-WVD357XL.js";
import "./chunk-37P6EC7R.js";
import "./chunk-RH5YHFLD.js";
import "./chunk-XDTKJWZK.js";
import "./chunk-PV2PVFPK.js";
import "./chunk-QOHD3WUR.js";
export {
  CdkDialogContainer,
  DEFAULT_DIALOG_CONFIG,
  DIALOG_DATA,
  DIALOG_SCROLL_STRATEGY,
  DIALOG_SCROLL_STRATEGY_PROVIDER,
  DIALOG_SCROLL_STRATEGY_PROVIDER_FACTORY,
  Dialog,
  DialogConfig,
  DialogModule,
  DialogRef,
  throwDialogContentAlreadyAttachedError
};
//# sourceMappingURL=@angular_cdk_dialog.js.map
